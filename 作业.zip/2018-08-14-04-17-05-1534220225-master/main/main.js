module.exports = function main() {
    console.log("Debug Info");
    return 'Hello World!';
};